"""
NSE Index Downloader

Downloads and processes NSE Index data separately from equity data.
"""

import asyncio
from datetime import date
from pathlib import Path
from typing import List, Optional
import pandas as pd
import logging

from ..core.base_downloader import BaseDownloader
from ..core.config import Config
from ..utils.async_downloader import AsyncDownloadManager, DownloadTask
from ..utils.memory_optimizer import MemoryOptimizer
from ..core.exceptions import DataProcessingError


class NSEIndexDownloader(BaseDownloader):
    """
    NSE Index data downloader
    
    Downloads NSE index data separately from equity data.
    """
    
    def __init__(self, config: Config):
        """Initialize NSE Index downloader"""
        super().__init__("NSE", "INDEX", config)
        self.memory_optimizer = MemoryOptimizer()
    
    def build_url(self, target_date: date) -> str:
        """Build NSE index download URL"""
        date_str = self.exchange_config.date_format
        formatted_date = target_date.strftime(date_str)
        filename = self.exchange_config.filename_pattern.format(date=formatted_date)
        return f"{self.exchange_config.base_url}/{filename}"
    
    def process_downloaded_data(self, file_data: bytes, file_date: date) -> Optional[pd.DataFrame]:
        """
        Process downloaded CSV file data in memory
        
        Args:
            file_data: Downloaded CSV file data as bytes
            file_date: Date of the data
            
        Returns:
            Processed DataFrame
        """
        try:
            import io
            
            # Read CSV data from memory
            df = pd.read_csv(io.BytesIO(file_data))
            
            # Transform data
            transformed_df = self.transform_data(df, file_date)
            
            self.logger.info(f"Processed NSE Index data for {file_date}: {len(transformed_df)} rows")
            return transformed_df
            
        except Exception as e:
            raise DataProcessingError(f"Error processing NSE Index data for {file_date}: {e}")
    
    def transform_data(self, df: pd.DataFrame, file_date: date) -> pd.DataFrame:
        """
        Transform NSE Index data according to original logic
        
        Args:
            df: Input DataFrame
            file_date: Date of the data
            
        Returns:
            Transformed DataFrame
        """
        try:
            with self.memory_optimizer.memory_monitor("nse_index_transform"):
                # Remove unwanted columns (from original code)
                columns_to_remove = ['Points Change', 'Change(%)', 'Turnover (Rs. Cr.)', 'P/E', 'P/B', 'Div Yield']
                existing_columns = [col for col in columns_to_remove if col in df.columns]
                df = df.drop(columns=existing_columns)
                
                # Convert Index Date to desired format
                if 'Index Date' in df.columns:
                    df['Index Date'] = pd.to_datetime(df['Index Date'], format='%d-%m-%Y', errors='coerce').dt.strftime('%Y%m%d')
                else:
                    # Add date column if not present
                    df['Index Date'] = file_date.strftime('%Y%m%d')
                
                # Ensure date consistency
                expected_date = file_date.strftime('%Y%m%d')
                if 'Index Date' in df.columns:
                    df['Index Date'] = expected_date
                
                # Optimize memory usage
                df = self.memory_optimizer.optimize_dataframe(df)
                
                self.logger.info(f"Transformed NSE Index data: {len(df)} rows, {len(df.columns)} columns")
                return df
                
        except Exception as e:
            raise DataProcessingError(f"Error transforming NSE Index data: {e}")

    def save_processed_data(self, df: pd.DataFrame, target_date: date) -> Path:
        """
        Save processed NSE Index DataFrame with real-time append to EQ buffer

        Args:
            df: Processed DataFrame
            target_date: Date of the data

        Returns:
            Path to saved file
        """
        try:
            # ALWAYS save separate file first
            filename = self.build_filename(target_date)
            output_path = self.data_path / filename

            # Save without header and index
            df.to_csv(output_path, index=False, header=False)
            self.logger.info(f"Saved NSE Index data: {filename}")

            # Then check if append to NSE EQ option is enabled
            if self.download_options.get('index_append_to_eq', False):
                # Append to NSE EQ buffer in memory
                if hasattr(self, 'append_service') and self.append_service:
                    success = self.append_service.append_data_to_buffer(
                        exchange='NSE',
                        segment='EQ',
                        date=target_date,
                        source_type='NSE_INDEX',
                        append_data=df
                    )

                    if success:
                        self.logger.info(f"Appended NSE Index data to EQ buffer for {target_date}")

                        # Check if EQ buffer is ready to save
                        if self.append_service.is_ready_for_save('NSE', 'EQ', target_date):
                            saved_path = self.append_service.save_buffer_to_disk('NSE', 'EQ', target_date)
                            if saved_path:
                                self.logger.info(f"Saved combined NSE EQ data: {saved_path.name}")
                    else:
                        self.logger.warning("Failed to append NSE Index data to EQ buffer")
                else:
                    self.logger.warning("Append service not available for NSE Index data")

            return output_path

        except Exception as e:
            from ..core.exceptions import FileOperationError
            raise FileOperationError(
                f"Failed to save NSE Index data for {target_date}",
                file_path=str(output_path if 'output_path' in locals() else 'unknown'),
                operation="save_csv"
            ) from e

    async def _download_implementation(self, working_days: List[date]) -> bool:
        """
        Implement NSE Index download logic with immediate processing
        
        Args:
            working_days: List of dates to download
            
        Returns:
            True if successful, False otherwise
        """
        try:
            success_count = 0
            
            # Process files one by one for immediate progress updates
            for i, target_date in enumerate(working_days):
                try:
                    # Update progress
                    progress = int((i / len(working_days)) * 100)
                    self._update_progress(f"Processing {target_date} ({i+1}/{len(working_days)})")
                    
                    # Create download task
                    url = self.build_url(target_date)
                    task = DownloadTask(
                        url=url,
                        date_str=target_date.strftime('%Y-%m-%d'),
                        target_date=target_date
                    )
                    
                    # Download file
                    async with AsyncDownloadManager(self.config) as download_manager:
                        # Update session timeout to current config value
                        await self.update_async_session_timeout(download_manager, self.config.download_settings.timeout_seconds)

                        results = await download_manager.download_multiple([task])
                        
                        if results and results[0].success:
                            result = results[0]
                            
                            # Process downloaded data immediately
                            processed_df = self.process_downloaded_data(result.file_data, target_date)
                            
                            if processed_df is not None:
                                # Save processed data
                                self.save_processed_data(processed_df, target_date)
                                success_count += 1
                                
                                # Update progress
                                self.completed_files += 1
                                progress = int(((i + 1) / len(working_days)) * 100)
                                self._update_progress(f"Completed {target_date}")
                                
                                self.logger.info(f"Successfully processed {target_date}")
                            else:
                                self._report_error(f"Failed to process data for {target_date}")
                        else:
                            error_msg = results[0].error_message if results else "Unknown download error"
                            # In fast mode, don't report as error if file is simply not available
                            if hasattr(self.config.download_settings, 'fast_mode') and self.config.download_settings.fast_mode:
                                if "not available" in error_msg.lower() or "404" in error_msg:
                                    # Check if it's a weekend or holiday
                                    is_weekend = target_date.weekday() >= 5
                                    is_holiday = self.config.holiday_manager.is_holiday(target_date)
                                    is_current_date = target_date == date.today()

                                    if not is_weekend and not is_holiday and not is_current_date:
                                        # File skipped for non-weekend, non-holiday, non-current date - notify user
                                        self._report_error(f"⚠️ NOTICE: File skipped for {target_date} (not weekend/holiday) - Server timeout or file unavailable")
                                    else:
                                        if is_current_date:
                                            self.logger.info(f"File not available for {target_date} (current date - files available after market close)")
                                        else:
                                            self.logger.info(f"File not available for {target_date} (weekend/holiday)")
                                else:
                                    self._report_error(f"Download failed for {target_date}: {error_msg}")
                            else:
                                self._report_error(f"Download failed for {target_date}: {error_msg}")
                            
                except Exception as e:
                    self._report_error(f"Error processing {target_date}: {e}")
                    continue
            
            self.logger.info(f"Successfully processed {success_count}/{len(working_days)} files")
            return success_count > 0
            
        except Exception as e:
            self._report_error(f"Download implementation failed: {e}")
            return False
