"""Performance Tests for NSE/BSE Data Downloader"""
