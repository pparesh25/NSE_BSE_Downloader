"""CLI Tests for NSE/BSE Data Downloader"""
