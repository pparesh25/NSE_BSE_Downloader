#!/usr/bin/env python3
"""
Debug script to investigate missing append data issue
"""

import sys
import os
from pathlib import Path
from datetime import date, timedelta
import pandas as pd

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.config import Config
from src.services.file_append_service import RealTimeAppendService

def debug_expected_downloads():
    """Debug expected downloads registration"""
    print("\n🔍 Debugging Expected Downloads Registration...")
    
    try:
        config = Config()
        append_service = RealTimeAppendService(config)
        
        test_date = date.today()
        
        # Test BSE scenario
        print(f"\n📋 Testing BSE scenario for {test_date}:")
        
        # Register expected downloads for BSE
        append_service.register_expected_download(
            exchange='BSE',
            segment='EQ',
            date=test_date,
            source_types=['BSE_INDEX']
        )
        
        # Check what's registered
        buffer_key = f"BSE_EQ_{test_date}"
        if buffer_key in append_service.expected_downloads:
            expected = append_service.expected_downloads[buffer_key]
            print(f"  ✅ Expected downloads registered: {expected}")
        else:
            print(f"  ❌ No expected downloads found for {buffer_key}")
            return False
        
        # Create BSE EQ data
        eq_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [2500, 3500],
            'CLOSE': [2550, 3550]
        })
        
        # Initialize EQ buffer
        append_service.initialize_eq_buffer('BSE', 'EQ', test_date, eq_data)
        print(f"  ✅ Initialized BSE EQ buffer with {len(eq_data)} rows")
        
        # Check if ready (should not be ready yet)
        is_ready = append_service.is_ready_for_save('BSE', 'EQ', test_date)
        print(f"  Ready before BSE Index append: {is_ready} (should be False)")
        
        # Get buffer status
        buffer_status = append_service.get_buffer_status()
        if buffer_key in buffer_status:
            status = buffer_status[buffer_key]
            print(f"  Buffer status: {status}")
            missing = set(status['expected']) - set(status['completed'])
            print(f"  Missing downloads: {missing}")
        
        # Now simulate BSE Index download
        index_data = pd.DataFrame({
            'SYMBOL': ['BSE500', 'SENSEX'],
            'OPEN': [25000, 60000],
            'CLOSE': [25100, 60200]
        })
        
        # Append BSE Index data
        success = append_service.append_data_to_buffer(
            exchange='BSE',
            segment='EQ',
            date=test_date,
            source_type='BSE_INDEX',
            append_data=index_data
        )
        
        print(f"  BSE Index append: {'✅ Success' if success else '❌ Failed'}")
        
        # Check if ready now
        is_ready = append_service.is_ready_for_save('BSE', 'EQ', test_date)
        print(f"  Ready after BSE Index append: {is_ready} (should be True)")
        
        if is_ready:
            # Get combined data
            combined_data = append_service.get_buffer_data('BSE', 'EQ', test_date)
            if combined_data is not None:
                print(f"  ✅ Combined data has {len(combined_data)} rows (expected: 4)")
                symbols = combined_data['SYMBOL'].tolist()
                print(f"  Symbols: {symbols}")
                return True
            else:
                print(f"  ❌ Failed to get combined data")
                return False
        else:
            # Get final buffer status
            buffer_status = append_service.get_buffer_status()
            if buffer_key in buffer_status:
                status = buffer_status[buffer_key]
                print(f"  Final buffer status: {status}")
                missing = set(status['expected']) - set(status['completed'])
                print(f"  Still missing: {missing}")
            return False
        
    except Exception as e:
        print(f"  ❌ Error debugging expected downloads: {e}")
        import traceback
        traceback.print_exc()
        return False

def debug_download_options():
    """Debug download options configuration"""
    print("\n🔍 Debugging Download Options...")
    
    try:
        config = Config()
        
        # Check if BSE Index append option exists in config
        print(f"📋 Checking download options configuration:")
        
        # Look for BSE index append option
        if hasattr(config, 'download_options'):
            options = config.download_options
            print(f"  Download options found: {options}")
        else:
            print(f"  ❌ No download_options found in config")
        
        # Check exchange configs
        if hasattr(config, 'exchanges'):
            exchanges = config.exchanges
            print(f"  Available exchanges: {list(exchanges.keys())}")
            
            if 'BSE_INDEX' in exchanges:
                bse_index_config = exchanges['BSE_INDEX']
                print(f"  BSE_INDEX config: {bse_index_config}")
            else:
                print(f"  ❌ BSE_INDEX not found in exchanges")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error debugging download options: {e}")
        import traceback
        traceback.print_exc()
        return False

def debug_buffer_key_generation():
    """Debug buffer key generation"""
    print("\n🔍 Debugging Buffer Key Generation...")
    
    try:
        config = Config()
        append_service = RealTimeAppendService(config)
        
        test_date = date.today()
        
        # Test different buffer key formats
        print(f"📋 Testing buffer key generation for {test_date}:")
        
        # Generate buffer key manually
        buffer_key = append_service._get_buffer_key('BSE', 'EQ', test_date)
        print(f"  Generated buffer key: '{buffer_key}'")
        
        # Test with different date formats
        date_str = test_date.strftime('%Y-%m-%d')
        print(f"  Date string: '{date_str}'")
        
        # Check if key matches expected format
        expected_key = f"BSE_EQ_{test_date}"
        print(f"  Expected key format: '{expected_key}'")
        print(f"  Keys match: {buffer_key == expected_key}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error debugging buffer keys: {e}")
        import traceback
        traceback.print_exc()
        return False

def debug_completion_tracking():
    """Debug completion tracking"""
    print("\n🔍 Debugging Completion Tracking...")
    
    try:
        config = Config()
        append_service = RealTimeAppendService(config)
        
        test_date = date.today()
        
        print(f"📋 Testing completion tracking for {test_date}:")
        
        # Register expected downloads
        append_service.register_expected_download(
            exchange='BSE',
            segment='EQ',
            date=test_date,
            source_types=['BSE_INDEX']
        )
        
        buffer_key = append_service._get_buffer_key('BSE', 'EQ', test_date)
        print(f"  Buffer key: {buffer_key}")
        
        # Check initial state
        if buffer_key in append_service.expected_downloads:
            expected = append_service.expected_downloads[buffer_key]
            print(f"  Expected: {expected}")
        
        if buffer_key in append_service.completed_downloads:
            completed = append_service.completed_downloads[buffer_key]
            print(f"  Completed: {completed}")
        else:
            print(f"  No completed downloads yet")
        
        # Mark as completed manually
        append_service.mark_download_completed('BSE', 'EQ', test_date, 'BSE_INDEX')
        
        # Check after marking complete
        if buffer_key in append_service.completed_downloads:
            completed = append_service.completed_downloads[buffer_key]
            print(f"  After marking complete: {completed}")
        
        # Check if ready
        is_ready = append_service.is_ready_for_save('BSE', 'EQ', test_date)
        print(f"  Ready after manual completion: {is_ready}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error debugging completion tracking: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all debug tests"""
    print("🚀 Debugging Missing Append Data Issue")
    print("=" * 50)
    
    tests = [
        ("Expected Downloads Registration", debug_expected_downloads),
        ("Download Options Configuration", debug_download_options),
        ("Buffer Key Generation", debug_buffer_key_generation),
        ("Completion Tracking", debug_completion_tracking)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Debug Results Summary:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("🎉 All debug tests passed - append service working correctly!")
    else:
        print("⚠️  Some debug tests failed. Issue identified.")
    
    return passed == len(results)

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
