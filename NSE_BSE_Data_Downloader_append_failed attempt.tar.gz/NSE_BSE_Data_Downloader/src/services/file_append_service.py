"""
Real-time Data Append Service

Handles appending data in memory during download process.
Manages EQ file data accumulation and real-time append operations.
"""

import logging
from datetime import date
from pathlib import Path
from typing import Dict, List, Optional, Set
import pandas as pd
from dataclasses import dataclass, field
from threading import Lock

from ..core.config import Config
from ..core.exceptions import FileOperationError


@dataclass
class DataBuffer:
    """In-memory data buffer for EQ files"""
    exchange: str
    segment: str
    date: date
    data: pd.DataFrame = field(default_factory=pd.DataFrame)
    has_base_data: bool = False
    pending_appends: Set[str] = field(default_factory=set)  # Set of source types waiting to append

    def __str__(self):
        return f"{self.exchange}-{self.segment} ({self.date}): {len(self.data)} rows"


class RealTimeAppendService:
    """
    Real-time data append service for in-memory operations

    This service manages EQ file data buffers and performs real-time
    append operations as data becomes available during downloads.
    """

    def __init__(self, config: Config):
        """Initialize real-time append service"""
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.data_buffers: Dict[str, DataBuffer] = {}  # Key: "exchange_segment_date"
        self.expected_downloads: Dict[str, Set[str]] = {}  # Key: buffer_key, Value: set of expected source types
        self.completed_downloads: Dict[str, Set[str]] = {}  # Key: buffer_key, Value: set of completed source types
        self.lock = Lock()  # Thread safety for concurrent operations

    def _get_buffer_key(self, exchange: str, segment: str, date: date) -> str:
        """Generate unique key for data buffer"""
        return f"{exchange}_{segment}_{date.strftime('%Y-%m-%d')}"

    def register_expected_download(self, exchange: str, segment: str, date: date,
                                 source_types: List[str]) -> None:
        """
        Register expected downloads for a specific EQ file

        Args:
            exchange: Exchange name ('NSE', 'BSE')
            segment: Segment name ('EQ')
            date: Date of the data
            source_types: List of source types that will append to this EQ file
        """
        buffer_key = self._get_buffer_key(exchange, segment, date)

        with self.lock:
            if buffer_key not in self.expected_downloads:
                self.expected_downloads[buffer_key] = set()
                self.completed_downloads[buffer_key] = set()

            self.expected_downloads[buffer_key].update(source_types)
            self.logger.info(f"Registered expected downloads for {buffer_key}: {source_types}")

    def initialize_eq_buffer(self, exchange: str, segment: str, date: date,
                           eq_data: pd.DataFrame) -> None:
        """
        Initialize EQ data buffer with base EQ data

        Args:
            exchange: Exchange name
            segment: Segment name
            date: Date of the data
            eq_data: Base EQ DataFrame
        """
        buffer_key = self._get_buffer_key(exchange, segment, date)

        with self.lock:
            if buffer_key not in self.data_buffers:
                self.data_buffers[buffer_key] = DataBuffer(
                    exchange=exchange,
                    segment=segment,
                    date=date,
                    data=eq_data.copy(),
                    has_base_data=True
                )
                self.logger.info(f"Initialized EQ buffer: {buffer_key} with {len(eq_data)} rows")
            else:
                # Update existing buffer with base data
                self.data_buffers[buffer_key].data = eq_data.copy()
                self.data_buffers[buffer_key].has_base_data = True
                self.logger.info(f"Updated EQ buffer: {buffer_key} with {len(eq_data)} rows")
    
    def append_data_to_buffer(self, exchange: str, segment: str, date: date,
                            source_type: str, append_data: pd.DataFrame) -> bool:
        """
        Append data to EQ buffer in memory

        Args:
            exchange: Target exchange name
            segment: Target segment name
            date: Date of the data
            source_type: Source type ('SME', 'NSE_INDEX', 'BSE_INDEX')
            append_data: Data to append

        Returns:
            True if successful, False otherwise
        """
        buffer_key = self._get_buffer_key(exchange, segment, date)

        with self.lock:
            try:
                # Create buffer if it doesn't exist
                if buffer_key not in self.data_buffers:
                    self.data_buffers[buffer_key] = DataBuffer(
                        exchange=exchange,
                        segment=segment,
                        date=date,
                        data=pd.DataFrame(),
                        has_base_data=False
                    )

                buffer = self.data_buffers[buffer_key]

                # Append data to buffer
                if buffer.data.empty:
                    buffer.data = append_data.copy()
                else:
                    buffer.data = pd.concat([buffer.data, append_data], ignore_index=True)

                # Mark this source type as completed
                if buffer_key in self.completed_downloads:
                    self.completed_downloads[buffer_key].add(source_type)

                self.logger.info(f"Appended {len(append_data)} rows from {source_type} to {buffer_key}")
                self.logger.info(f"Buffer now has {len(buffer.data)} total rows")

                return True

            except Exception as e:
                self.logger.error(f"Failed to append {source_type} data to {buffer_key}: {e}")
                return False
    
    def mark_download_completed(self, exchange: str, segment: str, date: date,
                              source_type: str) -> None:
        """
        Mark a download as completed (even if skipped)

        Args:
            exchange: Exchange name
            segment: Segment name
            date: Date of the data
            source_type: Source type that completed
        """
        buffer_key = self._get_buffer_key(exchange, segment, date)

        with self.lock:
            if buffer_key in self.completed_downloads:
                self.completed_downloads[buffer_key].add(source_type)
                self.logger.info(f"Marked {source_type} as completed for {buffer_key}")

    def is_ready_for_save(self, exchange: str, segment: str, date: date) -> bool:
        """
        Check if EQ buffer is ready to be saved to disk

        Args:
            exchange: Exchange name
            segment: Segment name
            date: Date of the data

        Returns:
            True if all expected downloads are complete
        """
        buffer_key = self._get_buffer_key(exchange, segment, date)

        with self.lock:
            if buffer_key not in self.expected_downloads:
                return True  # No append operations expected

            expected = self.expected_downloads[buffer_key]
            completed = self.completed_downloads.get(buffer_key, set())

            is_ready = expected.issubset(completed)

            if is_ready:
                self.logger.info(f"Buffer {buffer_key} ready for save: all expected downloads complete")
            else:
                missing = expected - completed
                self.logger.debug(f"Buffer {buffer_key} waiting for: {missing}")

            return is_ready
    
    def save_buffer_to_disk(self, exchange: str, segment: str, date: date) -> Optional[Path]:
        """
        Save EQ buffer data to disk

        Args:
            exchange: Exchange name
            segment: Segment name
            date: Date of the data

        Returns:
            Path to saved file or None if failed
        """
        buffer_key = self._get_buffer_key(exchange, segment, date)

        with self.lock:
            if buffer_key not in self.data_buffers:
                self.logger.warning(f"No buffer found for {buffer_key}")
                return None

            buffer = self.data_buffers[buffer_key]

            if buffer.data.empty:
                self.logger.warning(f"Buffer {buffer_key} is empty, skipping save")
                return None

            try:
                # Get output path - use .txt for EQ files, .csv for others
                data_path = self.config.get_data_path(exchange, segment)
                if segment == 'EQ':
                    filename = date.strftime('%Y-%m-%d') + f'-{exchange}-{segment}.txt'
                else:
                    filename = date.strftime('%Y-%m-%d') + f'-{exchange}-{segment}.csv'
                output_path = data_path / filename

                # Save to disk
                buffer.data.to_csv(output_path, index=False, header=False)

                self.logger.info(f"Saved buffer {buffer_key} to disk: {filename} ({len(buffer.data)} rows)")

                # Clean up buffer
                del self.data_buffers[buffer_key]
                if buffer_key in self.expected_downloads:
                    del self.expected_downloads[buffer_key]
                if buffer_key in self.completed_downloads:
                    del self.completed_downloads[buffer_key]

                return output_path

            except Exception as e:
                self.logger.error(f"Failed to save buffer {buffer_key}: {e}")
                return None
    
    def get_buffer_data(self, exchange: str, segment: str, date: date) -> Optional[pd.DataFrame]:
        """
        Get current buffer data

        Args:
            exchange: Exchange name
            segment: Segment name
            date: Date of the data

        Returns:
            DataFrame with current buffer data or None
        """
        buffer_key = self._get_buffer_key(exchange, segment, date)

        with self.lock:
            if buffer_key in self.data_buffers:
                return self.data_buffers[buffer_key].data.copy()
            return None

    def get_pending_buffers_count(self) -> int:
        """Get number of pending data buffers"""
        with self.lock:
            return len(self.data_buffers)

    def clear_all_buffers(self) -> None:
        """Clear all data buffers and tracking"""
        with self.lock:
            self.data_buffers.clear()
            self.expected_downloads.clear()
            self.completed_downloads.clear()
            self.logger.info("Cleared all data buffers")

    def get_buffer_status(self) -> Dict[str, Dict]:
        """
        Get status of all buffers

        Returns:
            Dictionary with buffer status information
        """
        with self.lock:
            status = {}
            for buffer_key, buffer in self.data_buffers.items():
                expected = self.expected_downloads.get(buffer_key, set())
                completed = self.completed_downloads.get(buffer_key, set())

                status[buffer_key] = {
                    'rows': len(buffer.data),
                    'has_base_data': buffer.has_base_data,
                    'expected': list(expected),
                    'completed': list(completed),
                    'ready_for_save': expected.issubset(completed)
                }

            return status
