#!/usr/bin/env python3
"""
Test script for Real-time Append Service functionality
Tests the new in-memory real-time append operations
"""

import sys
import os
import asyncio
from pathlib import Path
from datetime import date, timedelta
import pandas as pd

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.config import Config
from src.services.file_append_service import RealTimeAppendService
from src.downloaders.nse_sme_downloader import NSESMEDownloader
from src.downloaders.nse_eq_downloader import NSEEQDownloader

def test_realtime_append_basic():
    """Test basic real-time append functionality"""
    print("\n🧪 Testing basic real-time append functionality...")
    
    try:
        config = Config()
        append_service = RealTimeAppendService(config)
        
        test_date = date.today()
        
        # Register expected downloads
        append_service.register_expected_download(
            exchange='NSE',
            segment='EQ',
            date=test_date,
            source_types=['SME']
        )
        
        # Create EQ data
        eq_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [2500, 3500],
            'CLOSE': [2550, 3550]
        })
        
        # Initialize EQ buffer
        append_service.initialize_eq_buffer('NSE', 'EQ', test_date, eq_data)
        print(f"  Initialized EQ buffer with {len(eq_data)} rows")
        
        # Create SME data with _SME suffix
        sme_data = pd.DataFrame({
            'SYMBOL': ['SME1_SME', 'SME2_SME'],
            'OPEN': [100, 200],
            'CLOSE': [110, 220]
        })
        
        # Append SME data to buffer
        success = append_service.append_data_to_buffer(
            exchange='NSE',
            segment='EQ',
            date=test_date,
            source_type='SME',
            append_data=sme_data
        )
        
        if success:
            print(f"  ✅ Successfully appended SME data to buffer")
        else:
            print(f"  ❌ Failed to append SME data to buffer")
            return False
        
        # Check if ready to save
        is_ready = append_service.is_ready_for_save('NSE', 'EQ', test_date)
        print(f"  Buffer ready for save: {is_ready}")
        
        if is_ready:
            # Get combined data
            combined_data = append_service.get_buffer_data('NSE', 'EQ', test_date)
            if combined_data is not None:
                print(f"  Combined data has {len(combined_data)} rows (expected: 4)")
                
                # Check symbols
                symbols = combined_data['SYMBOL'].tolist()
                print(f"  Symbols: {symbols}")
                
                if len(combined_data) == 4 and 'SME1_SME' in symbols and 'SME2_SME' in symbols:
                    print("  ✅ Real-time append working correctly!")
                    return True
                else:
                    print("  ❌ Combined data not correct")
                    return False
            else:
                print("  ❌ Failed to get combined data")
                return False
        else:
            print("  ❌ Buffer not ready for save")
            return False
        
    except Exception as e:
        print(f"  ❌ Error testing real-time append: {e}")
        return False

def test_multiple_appends():
    """Test multiple append operations"""
    print("\n🧪 Testing multiple append operations...")
    
    try:
        config = Config()
        append_service = RealTimeAppendService(config)
        
        test_date = date.today()
        
        # Register expected downloads
        append_service.register_expected_download(
            exchange='NSE',
            segment='EQ',
            date=test_date,
            source_types=['SME', 'NSE_INDEX']
        )
        
        # Create EQ data
        eq_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [2500, 3500],
            'CLOSE': [2550, 3550]
        })
        
        # Initialize EQ buffer
        append_service.initialize_eq_buffer('NSE', 'EQ', test_date, eq_data)
        print(f"  Initialized EQ buffer with {len(eq_data)} rows")
        
        # Append SME data
        sme_data = pd.DataFrame({
            'SYMBOL': ['SME1_SME', 'SME2_SME'],
            'OPEN': [100, 200],
            'CLOSE': [110, 220]
        })
        
        success1 = append_service.append_data_to_buffer(
            exchange='NSE',
            segment='EQ',
            date=test_date,
            source_type='SME',
            append_data=sme_data
        )
        
        print(f"  SME append: {'✅ Success' if success1 else '❌ Failed'}")
        
        # Check if ready (should not be ready yet)
        is_ready = append_service.is_ready_for_save('NSE', 'EQ', test_date)
        print(f"  Ready after SME: {is_ready} (should be False)")
        
        # Append Index data
        index_data = pd.DataFrame({
            'SYMBOL': ['NIFTY50', 'BANKNIFTY'],
            'OPEN': [18000, 45000],
            'CLOSE': [18100, 45200]
        })
        
        success2 = append_service.append_data_to_buffer(
            exchange='NSE',
            segment='EQ',
            date=test_date,
            source_type='NSE_INDEX',
            append_data=index_data
        )
        
        print(f"  Index append: {'✅ Success' if success2 else '❌ Failed'}")
        
        # Check if ready now (should be ready)
        is_ready = append_service.is_ready_for_save('NSE', 'EQ', test_date)
        print(f"  Ready after Index: {is_ready} (should be True)")
        
        if is_ready:
            # Get combined data
            combined_data = append_service.get_buffer_data('NSE', 'EQ', test_date)
            if combined_data is not None:
                print(f"  Combined data has {len(combined_data)} rows (expected: 6)")
                
                # Check symbols
                symbols = combined_data['SYMBOL'].tolist()
                print(f"  Symbols: {symbols}")
                
                expected_symbols = ['RELIANCE', 'TCS', 'SME1_SME', 'SME2_SME', 'NIFTY50', 'BANKNIFTY']
                if len(combined_data) == 6 and all(sym in symbols for sym in expected_symbols):
                    print("  ✅ Multiple appends working correctly!")
                    return True
                else:
                    print("  ❌ Combined data not correct")
                    return False
            else:
                print("  ❌ Failed to get combined data")
                return False
        else:
            print("  ❌ Buffer not ready for save after all appends")
            return False
        
    except Exception as e:
        print(f"  ❌ Error testing multiple appends: {e}")
        return False

def test_skip_handling():
    """Test handling of skipped downloads"""
    print("\n🧪 Testing skip handling...")
    
    try:
        config = Config()
        append_service = RealTimeAppendService(config)
        
        test_date = date.today()
        
        # Register expected downloads
        append_service.register_expected_download(
            exchange='NSE',
            segment='EQ',
            date=test_date,
            source_types=['SME', 'NSE_INDEX']
        )
        
        # Create EQ data
        eq_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [2500, 3500],
            'CLOSE': [2550, 3550]
        })
        
        # Initialize EQ buffer
        append_service.initialize_eq_buffer('NSE', 'EQ', test_date, eq_data)
        print(f"  Initialized EQ buffer with {len(eq_data)} rows")
        
        # Append SME data
        sme_data = pd.DataFrame({
            'SYMBOL': ['SME1_SME', 'SME2_SME'],
            'OPEN': [100, 200],
            'CLOSE': [110, 220]
        })
        
        success1 = append_service.append_data_to_buffer(
            exchange='NSE',
            segment='EQ',
            date=test_date,
            source_type='SME',
            append_data=sme_data
        )
        
        print(f"  SME append: {'✅ Success' if success1 else '❌ Failed'}")
        
        # Mark NSE_INDEX as completed (skipped)
        append_service.mark_download_completed('NSE', 'EQ', test_date, 'NSE_INDEX')
        print(f"  Marked NSE_INDEX as completed (skipped)")
        
        # Check if ready now (should be ready)
        is_ready = append_service.is_ready_for_save('NSE', 'EQ', test_date)
        print(f"  Ready after skip: {is_ready} (should be True)")
        
        if is_ready:
            # Get combined data
            combined_data = append_service.get_buffer_data('NSE', 'EQ', test_date)
            if combined_data is not None:
                print(f"  Combined data has {len(combined_data)} rows (expected: 4)")
                
                # Check symbols (should only have EQ + SME, no Index)
                symbols = combined_data['SYMBOL'].tolist()
                print(f"  Symbols: {symbols}")
                
                expected_symbols = ['RELIANCE', 'TCS', 'SME1_SME', 'SME2_SME']
                if len(combined_data) == 4 and all(sym in symbols for sym in expected_symbols):
                    print("  ✅ Skip handling working correctly!")
                    return True
                else:
                    print("  ❌ Combined data not correct after skip")
                    return False
            else:
                print("  ❌ Failed to get combined data")
                return False
        else:
            print("  ❌ Buffer not ready for save after skip")
            return False
        
    except Exception as e:
        print(f"  ❌ Error testing skip handling: {e}")
        return False

def main():
    """Run all real-time append tests"""
    print("🚀 Testing Real-time Append Service")
    print("=" * 50)
    
    tests = [
        ("Basic Real-time Append", test_realtime_append_basic),
        ("Multiple Append Operations", test_multiple_appends),
        ("Skip Handling", test_skip_handling)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("🎉 All real-time append tests passed!")
        return True
    else:
        print("⚠️  Some tests failed. Please check the implementation.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
