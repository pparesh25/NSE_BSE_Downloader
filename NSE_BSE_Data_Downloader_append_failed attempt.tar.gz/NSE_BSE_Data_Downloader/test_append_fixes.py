#!/usr/bin/env python3
"""
Test script to verify append fixes
"""

import sys
import os
from pathlib import Path
from datetime import date, timedelta
import pandas as pd

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.config import Config
from src.downloaders.nse_eq_downloader import NSEEQDownloader
from src.downloaders.bse_eq_downloader import BSEEQDownloader
from src.downloaders.nse_sme_downloader import NSESMEDownloader
from src.downloaders.nse_index_downloader import NSEIndexDownloader
from src.downloaders.bse_index_downloader import BSEIndexDownloader
from src.services.file_append_service import RealTimeAppendService

def test_separate_file_saving():
    """Test that separate files are always saved"""
    print("\n🔍 Testing Separate File Saving...")
    
    try:
        config = Config()
        test_date = date.today() - timedelta(days=1)  # Use yesterday to avoid weekend issues
        
        # Test NSE SME with append enabled
        print(f"\n📋 Testing NSE SME separate file saving for {test_date}:")
        
        nse_sme = NSESMEDownloader(config)
        nse_sme.download_options = {'sme_append_to_eq': True}  # Enable append
        
        # Create test data
        test_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE_SME', 'TCS_SME'],
            'OPEN': [100, 200],
            'CLOSE': [110, 220]
        })
        
        # Save data (should save separate file even with append enabled)
        saved_path = nse_sme.save_processed_data(test_data, test_date)
        
        if saved_path and saved_path.exists():
            print(f"  ✅ NSE SME separate file saved: {saved_path.name}")
            print(f"  File size: {saved_path.stat().st_size} bytes")
        else:
            print(f"  ❌ NSE SME separate file not saved")
            return False
        
        # Test BSE Index with append enabled
        print(f"\n📋 Testing BSE Index separate file saving for {test_date}:")
        
        bse_index = BSEIndexDownloader(config)
        bse_index.download_options = {'bse_index_append_to_eq': True}  # Enable append
        
        # Create test data
        test_data = pd.DataFrame({
            'SYMBOL': ['BSE500', 'SENSEX'],
            'OPEN': [25000, 60000],
            'CLOSE': [25100, 60200]
        })
        
        # Save data (should save separate file even with append enabled)
        saved_path = bse_index.save_processed_data(test_data, test_date)
        
        if saved_path and saved_path.exists():
            print(f"  ✅ BSE Index separate file saved: {saved_path.name}")
            print(f"  File size: {saved_path.stat().st_size} bytes")
        else:
            print(f"  ❌ BSE Index separate file not saved")
            return False
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error testing separate file saving: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_txt_format():
    """Test that EQ files are saved as .txt"""
    print("\n🔍 Testing .txt Format for EQ Files...")
    
    try:
        config = Config()
        test_date = date.today() - timedelta(days=1)
        
        # Test NSE EQ
        print(f"\n📋 Testing NSE EQ .txt format for {test_date}:")
        
        nse_eq = NSEEQDownloader(config)
        
        # Create test data
        test_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [2500, 3500],
            'CLOSE': [2550, 3550]
        })
        
        # Save data
        saved_path = nse_eq.save_processed_data(test_data, test_date)
        
        if saved_path and saved_path.exists():
            if saved_path.suffix == '.txt':
                print(f"  ✅ NSE EQ saved as .txt: {saved_path.name}")
            else:
                print(f"  ❌ NSE EQ saved as {saved_path.suffix}, expected .txt")
                return False
        else:
            print(f"  ❌ NSE EQ file not saved")
            return False
        
        # Test BSE EQ
        print(f"\n📋 Testing BSE EQ .txt format for {test_date}:")
        
        bse_eq = BSEEQDownloader(config)
        
        # Save data
        saved_path = bse_eq.save_processed_data(test_data, test_date)
        
        if saved_path and saved_path.exists():
            if saved_path.suffix == '.txt':
                print(f"  ✅ BSE EQ saved as .txt: {saved_path.name}")
            else:
                print(f"  ❌ BSE EQ saved as {saved_path.suffix}, expected .txt")
                return False
        else:
            print(f"  ❌ BSE EQ file not saved")
            return False
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error testing .txt format: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_append_service_txt_format():
    """Test that append service saves combined files as .txt"""
    print("\n🔍 Testing Append Service .txt Format...")
    
    try:
        config = Config()
        append_service = RealTimeAppendService(config)
        test_date = date.today() - timedelta(days=1)
        
        # Test BSE scenario
        print(f"\n📋 Testing BSE append service .txt format for {test_date}:")
        
        # Register expected downloads
        append_service.register_expected_download(
            exchange='BSE',
            segment='EQ',
            date=test_date,
            source_types=['BSE_INDEX']
        )
        
        # Create BSE EQ data
        eq_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [2500, 3500],
            'CLOSE': [2550, 3550]
        })
        
        # Initialize buffer
        append_service.initialize_eq_buffer('BSE', 'EQ', test_date, eq_data)
        
        # Create BSE Index data
        index_data = pd.DataFrame({
            'SYMBOL': ['BSE500', 'SENSEX'],
            'OPEN': [25000, 60000],
            'CLOSE': [25100, 60200]
        })
        
        # Append data
        success = append_service.append_data_to_buffer(
            exchange='BSE',
            segment='EQ',
            date=test_date,
            source_type='BSE_INDEX',
            append_data=index_data
        )
        
        if not success:
            print(f"  ❌ Failed to append BSE Index data")
            return False
        
        # Save buffer
        if append_service.is_ready_for_save('BSE', 'EQ', test_date):
            saved_path = append_service.save_buffer_to_disk('BSE', 'EQ', test_date)
            
            if saved_path and saved_path.exists():
                if saved_path.suffix == '.txt':
                    print(f"  ✅ Combined BSE EQ saved as .txt: {saved_path.name}")
                    print(f"  File size: {saved_path.stat().st_size} bytes")
                    
                    # Check content
                    with open(saved_path, 'r') as f:
                        lines = f.readlines()
                        print(f"  Combined file has {len(lines)} lines")
                        if len(lines) >= 4:  # 2 EQ + 2 Index
                            print(f"  ✅ Combined data includes both EQ and Index data")
                        else:
                            print(f"  ⚠️  Combined file may be missing data")
                else:
                    print(f"  ❌ Combined file saved as {saved_path.suffix}, expected .txt")
                    return False
            else:
                print(f"  ❌ Combined file not saved")
                return False
        else:
            print(f"  ❌ Buffer not ready for save")
            return False
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error testing append service .txt format: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("🚀 Testing Append Service Fixes")
    print("=" * 50)
    
    tests = [
        ("Separate File Saving", test_separate_file_saving),
        (".txt Format for EQ Files", test_txt_format),
        ("Append Service .txt Format", test_append_service_txt_format)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("🎉 All append fixes working correctly!")
    else:
        print("⚠️  Some fixes need attention.")
    
    return passed == len(results)

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
