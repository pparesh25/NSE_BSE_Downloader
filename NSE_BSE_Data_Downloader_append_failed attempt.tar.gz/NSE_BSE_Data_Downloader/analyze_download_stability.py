#!/usr/bin/env python3
"""
Comprehensive analysis of download stability issues
"""

import sys
import os
from pathlib import Path
from datetime import date, timedelta
import yaml

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.config import Config
from src.utils.user_preferences import UserPreferences

def analyze_fast_download_mode():
    """Analyze fast download mode configuration and impact"""
    print("\n🔍 Analyzing Fast Download Mode...")
    
    try:
        config = Config()
        user_prefs = UserPreferences()
        
        print(f"\n📋 Fast Download Mode Configuration:")
        
        # Check config.yaml settings
        print(f"  Config YAML fast_mode: {config.download_settings.fast_mode}")
        print(f"  Config YAML timeout_seconds: {config.download_settings.timeout_seconds}")
        print(f"  Config YAML rate_limit_delay: {config.download_settings.rate_limit_delay}")
        print(f"  Config YAML retry_attempts: {config.download_settings.retry_attempts}")
        
        # Check user preferences
        print(f"\n  User Preferences fast_mode: {user_prefs.get_fast_mode()}")
        print(f"  User Preferences timeout_seconds: {user_prefs.get_timeout_seconds()}")
        
        # Analyze fast mode impact
        print(f"\n📊 Fast Mode Impact Analysis:")
        print(f"  ✅ Fast mode reduces delays to max 0.3s (from {config.download_settings.rate_limit_delay}s)")
        print(f"  ✅ Fast mode uses intelligent retry with server-specific attempts")
        print(f"  ⚠️  Fast mode may skip files on timeout/404 without proper retry")
        print(f"  ⚠️  Fast mode treats 'timeout' errors as 'file not available'")
        
        # Check for potential issues
        issues = []
        
        if config.download_settings.fast_mode and config.download_settings.timeout_seconds < 5:
            issues.append("Fast mode + low timeout may cause premature file skipping")
        
        if config.download_settings.rate_limit_delay < 0.2:
            issues.append("Very low rate limit delay may trigger server rate limiting")
        
        if config.download_settings.retry_attempts < 3:
            issues.append("Low retry attempts may miss temporarily unavailable files")
        
        if issues:
            print(f"\n⚠️  Potential Issues:")
            for issue in issues:
                print(f"    - {issue}")
        else:
            print(f"\n✅ No obvious fast mode configuration issues detected")
        
        return len(issues) == 0
        
    except Exception as e:
        print(f"  ❌ Error analyzing fast download mode: {e}")
        import traceback
        traceback.print_exc()
        return False

def analyze_timeout_configurations():
    """Analyze all timeout configurations for conflicts"""
    print("\n🔍 Analyzing Timeout Configurations...")
    
    try:
        config = Config()
        user_prefs = UserPreferences()
        
        print(f"\n📋 Timeout Configuration Sources:")
        
        # Config YAML timeouts
        print(f"  Config YAML timeout_seconds: {config.download_settings.timeout_seconds}s")
        print(f"  Config YAML rate_limit_delay: {config.download_settings.rate_limit_delay}s")
        
        # User preferences timeouts
        print(f"  User Preferences timeout_seconds: {user_prefs.get_timeout_seconds()}s")
        
        # Default timeouts in code
        print(f"\n📋 Default Timeouts in Code:")
        print(f"  DownloadSettings default: 30s")
        print(f"  UserPreferences default: 5s")
        print(f"  GUI SpinBox default: 5s")
        print(f"  CLI default: 10s")
        
        # Adaptive timeouts
        print(f"\n📋 Adaptive Timeouts (Server-Specific):")
        print(f"  BSE INDEX files: max(base_timeout, 8s)")
        print(f"  BSE EQ files: max(base_timeout, 6s)")
        print(f"  NSE SME files: max(base_timeout, 10s)")
        print(f"  NSE FO files: max(base_timeout, 8s)")
        print(f"  NSE EQ files: max(base_timeout, 7s)")
        
        # Check for conflicts
        conflicts = []
        
        config_timeout = config.download_settings.timeout_seconds
        user_timeout = user_prefs.get_timeout_seconds()
        
        if config_timeout != user_timeout:
            conflicts.append(f"Config timeout ({config_timeout}s) != User preference timeout ({user_timeout}s)")
        
        if config.download_settings.rate_limit_delay > config_timeout:
            conflicts.append(f"Rate limit delay ({config.download_settings.rate_limit_delay}s) > timeout ({config_timeout}s)")
        
        # Check if GUI timeout is being overridden
        if user_timeout == 5 and config_timeout != 5:
            conflicts.append(f"GUI default (5s) may be overridden by config ({config_timeout}s)")
        
        if conflicts:
            print(f"\n⚠️  Timeout Conflicts Detected:")
            for conflict in conflicts:
                print(f"    - {conflict}")
        else:
            print(f"\n✅ No timeout conflicts detected")
        
        # Recommendations
        print(f"\n💡 Recommendations:")
        print(f"  - Use consistent timeout across all sources")
        print(f"  - Consider server-specific timeouts (NSE SME needs 10s+)")
        print(f"  - Ensure rate_limit_delay < timeout_seconds")
        print(f"  - Test with different timeout values for stability")
        
        return len(conflicts) == 0
        
    except Exception as e:
        print(f"  ❌ Error analyzing timeout configurations: {e}")
        import traceback
        traceback.print_exc()
        return False

def analyze_memory_processing():
    """Analyze memory processing and potential interruptions"""
    print("\n🔍 Analyzing Memory Processing...")
    
    try:
        print(f"\n📋 Memory Processing Components:")
        
        # In-memory processing features
        print(f"  ✅ RealTimeAppendService - manages data buffers in memory")
        print(f"  ✅ AsyncDownloadManager - downloads to memory before disk")
        print(f"  ✅ MemoryOptimizer - optimizes DataFrames in memory")
        print(f"  ✅ ZIP extraction - processes ZIP files in memory")
        
        # Potential interruption points
        print(f"\n⚠️  Potential Interruption Points:")
        print(f"  - Large DataFrame operations may block event loop")
        print(f"  - ZIP extraction for large files may cause delays")
        print(f"  - Buffer operations with threading locks")
        print(f"  - Concurrent append operations")
        
        # Memory usage patterns
        print(f"\n📊 Memory Usage Patterns:")
        print(f"  - Each download loads full file into memory")
        print(f"  - DataFrames created for each file")
        print(f"  - Append buffers accumulate data until ready")
        print(f"  - Multiple concurrent downloads = multiple memory buffers")
        
        # Recommendations
        print(f"\n💡 Memory Processing Recommendations:")
        print(f"  - Monitor memory usage during large downloads")
        print(f"  - Consider streaming for very large files")
        print(f"  - Implement memory pressure detection")
        print(f"  - Add buffer size limits")
        print(f"  - Use async/await properly to avoid blocking")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error analyzing memory processing: {e}")
        import traceback
        traceback.print_exc()
        return False

def analyze_file_skipping_logic():
    """Analyze file skipping logic in fast mode"""
    print("\n🔍 Analyzing File Skipping Logic...")
    
    try:
        print(f"\n📋 File Skipping Conditions in Fast Mode:")
        
        # Conditions that trigger skipping
        print(f"  Skip Triggers:")
        print(f"    - 'not available' in error message (case insensitive)")
        print(f"    - '404' in error message")
        print(f"    - 'timeout' in error message (case insensitive)")
        
        # Weekend/holiday logic
        print(f"\n  Weekend/Holiday Logic:")
        print(f"    - Files skipped silently for weekends (Sat/Sun)")
        print(f"    - Files skipped silently for known holidays")
        print(f"    - Files skipped silently for current date")
        print(f"    - Files skipped with WARNING for other dates")
        
        # Potential issues
        print(f"\n⚠️  Potential File Skipping Issues:")
        print(f"    - Network timeouts treated as 'file not available'")
        print(f"    - Server rate limiting may trigger 'timeout' errors")
        print(f"    - Temporary server issues cause permanent skips")
        print(f"    - No retry for 'skipped' files in same session")
        
        # Solutions
        print(f"\n💡 File Skipping Solutions:")
        print(f"    - Distinguish between timeout and 404 errors")
        print(f"    - Implement retry for timeout errors")
        print(f"    - Add manual retry option for skipped files")
        print(f"    - Log skipped files for later review")
        print(f"    - Provide 'retry skipped' functionality")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Error analyzing file skipping logic: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run comprehensive download stability analysis"""
    print("🚀 Download Stability Analysis")
    print("=" * 50)
    
    analyses = [
        ("Fast Download Mode", analyze_fast_download_mode),
        ("Timeout Configurations", analyze_timeout_configurations),
        ("Memory Processing", analyze_memory_processing),
        ("File Skipping Logic", analyze_file_skipping_logic)
    ]
    
    results = []
    for analysis_name, analysis_func in analyses:
        print(f"\n📋 Running: {analysis_name}")
        result = analysis_func()
        results.append((analysis_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Analysis Results Summary:")
    print("=" * 50)
    
    passed = 0
    for analysis_name, result in results:
        status = "✅ GOOD" if result else "⚠️  NEEDS ATTENTION"
        print(f"  {status}: {analysis_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{len(results)} analyses show good configuration")
    
    # Final recommendations
    print(f"\n🎯 Key Recommendations for Download Stability:")
    print(f"  1. Increase timeout for NSE SME files (10s minimum)")
    print(f"  2. Distinguish timeout errors from 404 errors")
    print(f"  3. Implement retry mechanism for timeout errors")
    print(f"  4. Add 'retry skipped files' functionality")
    print(f"  5. Monitor memory usage during large downloads")
    print(f"  6. Use consistent timeout configuration across all components")
    
    return passed >= len(results) - 1  # Allow one analysis to need attention

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
