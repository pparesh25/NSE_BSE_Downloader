"""
CLI Module for NSE/BSE Data Downloader

Provides command-line interface functionality including:
- Interactive menus and navigation
- Progress visualization
- Command parsing and execution
- Rich terminal output
"""
