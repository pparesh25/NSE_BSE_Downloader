#!/usr/bin/env python3
"""
Test script for File Append Service functionality
Tests the new append service that handles timing issues
"""

import sys
import os
import asyncio
from pathlib import Path
from datetime import date, timedelta
import pandas as pd

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.config import Config
from src.services.file_append_service import FileAppendService, AppendTask
from src.downloaders.nse_sme_downloader import NSESMEDownloader

async def test_append_service_basic():
    """Test basic append service functionality"""
    print("\n🧪 Testing basic append service functionality...")
    
    try:
        config = Config()
        append_service = FileAppendService(config)
        
        # Create test directories
        test_date = date.today()
        nse_sme_path = config.get_data_path('NSE', 'SME')
        nse_eq_path = config.get_data_path('NSE', 'EQ')
        nse_sme_path.mkdir(parents=True, exist_ok=True)
        nse_eq_path.mkdir(parents=True, exist_ok=True)
        
        # Create test SME file
        sme_filename = test_date.strftime('%Y-%m-%d') + '-NSE-SME.csv'
        sme_file_path = nse_sme_path / sme_filename
        sme_data = pd.DataFrame({
            'SYMBOL': ['SME1_SME', 'SME2_SME'],
            'OPEN': [100, 200],
            'CLOSE': [110, 220]
        })
        sme_data.to_csv(sme_file_path, index=False, header=False)
        print(f"  Created test SME file: {sme_filename}")
        
        # Create test EQ file (simulating it being created later)
        eq_filename = test_date.strftime('%Y-%m-%d') + '-NSE-EQ.csv'
        eq_file_path = nse_eq_path / eq_filename
        eq_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [2500, 3500],
            'CLOSE': [2550, 3550]
        })
        
        # Add append task
        append_service.add_append_task(
            source_file=sme_file_path,
            target_file=eq_file_path,
            source_type='SME',
            date=test_date
        )
        
        print(f"  Added append task: SME -> EQ")
        print(f"  Pending tasks: {append_service.get_pending_tasks_count()}")
        
        # Simulate EQ file creation after delay
        async def create_eq_file_delayed():
            await asyncio.sleep(3)  # 3 second delay
            eq_data.to_csv(eq_file_path, index=False, header=False)
            print(f"  Created EQ file after delay: {eq_filename}")
        
        # Start both tasks
        eq_task = asyncio.create_task(create_eq_file_delayed())
        append_task = asyncio.create_task(append_service.process_pending_tasks())
        
        # Wait for both to complete
        await asyncio.gather(eq_task, append_task)
        
        # Check results
        if eq_file_path.exists():
            final_data = pd.read_csv(eq_file_path, header=None)
            print(f"  Final EQ file has {len(final_data)} rows (should be 4: 2 EQ + 2 SME)")
            
            if len(final_data) == 4:
                print("  ✅ Append service working correctly!")
                success = True
            else:
                print("  ❌ Append service not working properly")
                success = False
        else:
            print("  ❌ EQ file not found after append")
            success = False
        
        # Clean up
        if sme_file_path.exists():
            sme_file_path.unlink()
        if eq_file_path.exists():
            eq_file_path.unlink()
        
        return success
        
    except Exception as e:
        print(f"  ❌ Error testing append service: {e}")
        return False

async def test_sme_suffix_with_append_service():
    """Test SME suffix with append service integration"""
    print("\n🧪 Testing SME suffix with append service...")
    
    try:
        config = Config()
        append_service = FileAppendService(config)
        downloader = NSESMEDownloader(config)
        
        # Set options and append service
        downloader.set_download_options({
            'sme_add_suffix': True,
            'sme_append_to_eq': True
        })
        downloader.set_append_service(append_service)
        
        # Create test data
        test_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'OPEN': [100, 200],
            'CLOSE': [110, 220]
        })
        
        # Transform and save data
        test_date = date.today()
        transformed_data = downloader.transform_data(test_data, test_date)
        saved_path = downloader.save_processed_data(transformed_data, test_date)
        
        # Check if suffix was added
        symbols = transformed_data['SYMBOL'].tolist()
        print(f"  Transformed symbols: {symbols}")
        
        if all(str(symbol).endswith('_SME') for symbol in symbols):
            print("  ✅ SME suffix (_SME) working correctly!")
        else:
            print("  ❌ SME suffix not working properly")
            return False
        
        # Check if append task was registered
        pending_count = append_service.get_pending_tasks_count()
        print(f"  Pending append tasks: {pending_count}")
        
        if pending_count > 0:
            print("  ✅ Append task registered successfully!")
            success = True
        else:
            print("  ❌ Append task not registered")
            success = False
        
        # Clean up
        if saved_path.exists():
            saved_path.unlink()
        
        return success
        
    except Exception as e:
        print(f"  ❌ Error testing SME suffix with append service: {e}")
        return False

async def test_multiple_append_tasks():
    """Test multiple append tasks"""
    print("\n🧪 Testing multiple append tasks...")
    
    try:
        config = Config()
        append_service = FileAppendService(config)
        
        test_date = date.today()
        
        # Create multiple source files
        sources = []
        for i, source_type in enumerate(['SME', 'NSE_INDEX']):
            source_path = config.get_data_path('NSE', source_type.split('_')[-1])
            source_path.mkdir(parents=True, exist_ok=True)
            
            filename = test_date.strftime('%Y-%m-%d') + f'-NSE-{source_type.split("_")[-1]}.csv'
            file_path = source_path / filename
            
            data = pd.DataFrame({
                'SYMBOL': [f'{source_type}1', f'{source_type}2'],
                'VALUE': [100 + i*100, 200 + i*100]
            })
            data.to_csv(file_path, index=False, header=False)
            sources.append(file_path)
            
            # Add append task
            eq_path = config.get_data_path('NSE', 'EQ')
            eq_filename = test_date.strftime('%Y-%m-%d') + '-NSE-EQ.csv'
            eq_file_path = eq_path / eq_filename
            
            append_service.add_append_task(
                source_file=file_path,
                target_file=eq_file_path,
                source_type=source_type,
                date=test_date
            )
        
        print(f"  Added {len(sources)} append tasks")
        print(f"  Pending tasks: {append_service.get_pending_tasks_count()}")
        
        # Create EQ file
        eq_path = config.get_data_path('NSE', 'EQ')
        eq_path.mkdir(parents=True, exist_ok=True)
        eq_filename = test_date.strftime('%Y-%m-%d') + '-NSE-EQ.csv'
        eq_file_path = eq_path / eq_filename
        
        eq_data = pd.DataFrame({
            'SYMBOL': ['RELIANCE', 'TCS'],
            'VALUE': [2500, 3500]
        })
        eq_data.to_csv(eq_file_path, index=False, header=False)
        
        # Process append tasks
        results = await append_service.process_pending_tasks()
        print(f"  Append results: {results}")
        
        # Check final file
        if eq_file_path.exists():
            final_data = pd.read_csv(eq_file_path, header=None)
            expected_rows = 2 + len(sources) * 2  # 2 EQ + 2*sources
            print(f"  Final file has {len(final_data)} rows (expected: {expected_rows})")
            
            if len(final_data) == expected_rows:
                print("  ✅ Multiple append tasks working correctly!")
                success = True
            else:
                print("  ❌ Multiple append tasks not working properly")
                success = False
        else:
            print("  ❌ Final file not found")
            success = False
        
        # Clean up
        for source_file in sources:
            if source_file.exists():
                source_file.unlink()
        if eq_file_path.exists():
            eq_file_path.unlink()
        
        return success
        
    except Exception as e:
        print(f"  ❌ Error testing multiple append tasks: {e}")
        return False

async def main():
    """Run all append service tests"""
    print("🚀 Testing File Append Service")
    print("=" * 50)
    
    tests = [
        ("Basic Append Service", test_append_service_basic),
        ("SME Suffix with Append Service", test_sme_suffix_with_append_service),
        ("Multiple Append Tasks", test_multiple_append_tasks)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        result = await test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("🎉 All append service tests passed!")
        return True
    else:
        print("⚠️  Some tests failed. Please check the implementation.")
        return False

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
