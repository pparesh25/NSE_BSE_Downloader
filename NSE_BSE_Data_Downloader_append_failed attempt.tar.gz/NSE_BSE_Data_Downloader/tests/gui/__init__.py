"""GUI Tests for NSE/BSE Data Downloader"""
