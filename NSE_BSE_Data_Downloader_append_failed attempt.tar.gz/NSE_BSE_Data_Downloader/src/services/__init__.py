"""
Services Package

Contains service classes for handling various application operations.
"""

from .file_append_service import RealTimeAppendService

__all__ = ['RealTimeAppendService']
