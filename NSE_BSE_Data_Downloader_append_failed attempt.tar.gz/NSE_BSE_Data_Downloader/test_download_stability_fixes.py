#!/usr/bin/env python3
"""
Test script to verify download stability fixes
"""

import sys
import os
from pathlib import Path
from datetime import date, timedelta
import yaml

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.core.config import Config
from src.utils.user_preferences import UserPreferences

def test_timeout_configuration_fixes():
    """Test that timeout configurations are now consistent"""
    print("\n🔍 Testing Timeout Configuration Fixes...")
    
    try:
        config = Config()
        user_prefs = UserPreferences()
        
        config_timeout = config.download_settings.timeout_seconds
        user_timeout = user_prefs.get_timeout_seconds()
        retry_attempts = config.download_settings.retry_attempts
        
        print(f"  Config timeout: {config_timeout}s")
        print(f"  User preferences timeout: {user_timeout}s")
        print(f"  Retry attempts: {retry_attempts}")
        
        # Check if timeouts are consistent
        timeout_consistent = config_timeout == user_timeout
        retry_improved = retry_attempts >= 3
        timeout_adequate = config_timeout >= 10
        
        print(f"\n  ✅ Timeout consistency: {'PASS' if timeout_consistent else 'FAIL'}")
        print(f"  ✅ Retry attempts improved: {'PASS' if retry_improved else 'FAIL'}")
        print(f"  ✅ Timeout adequate: {'PASS' if timeout_adequate else 'FAIL'}")
        
        return timeout_consistent and retry_improved and timeout_adequate
        
    except Exception as e:
        print(f"  ❌ Error testing timeout fixes: {e}")
        return False

def test_error_classification():
    """Test error classification improvements"""
    print("\n🔍 Testing Error Classification...")
    
    try:
        from src.utils.async_downloader import AsyncDownloadManager
        from src.utils.async_downloader import DownloadTask
        
        # Create test instance
        config = Config()
        manager = AsyncDownloadManager(config)
        test_task = DownloadTask(
            url="https://test.com/file.csv",
            date_str="2025-01-01",
            target_date=date(2025, 1, 1)
        )
        
        # Test different error types
        test_cases = [
            ("Request timeout after 10s", "timeout", True),
            ("404 Not Found", "file_not_found", False),
            ("File not available", "file_not_found", False),
            ("Connection refused", "network", True),
            ("Server error 500", "server_error", True),
            ("TIMEOUT: Request timeout after 10s", "timeout", True),
        ]
        
        all_passed = True
        for error_msg, expected_type, expected_retry in test_cases:
            result = manager._classify_error(error_msg, test_task)
            
            type_correct = result["type"] == expected_type
            retry_correct = result["should_retry"] == expected_retry
            
            status = "✅ PASS" if (type_correct and retry_correct) else "❌ FAIL"
            print(f"  {status}: '{error_msg}' -> {result['type']} (retry: {result['should_retry']})")
            
            if not (type_correct and retry_correct):
                all_passed = False
        
        return all_passed
        
    except Exception as e:
        print(f"  ❌ Error testing error classification: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_downloader_error_handling():
    """Test improved error handling in downloaders"""
    print("\n🔍 Testing Downloader Error Handling...")
    
    try:
        # Test that downloaders can distinguish timeout vs 404 errors
        from src.downloaders.nse_eq_downloader import NSEEQDownloader
        from src.downloaders.bse_eq_downloader import BSEEQDownloader
        
        # Create test instances
        config = Config()
        nse_downloader = NSEEQDownloader(config)
        bse_downloader = BSEEQDownloader(config)
        
        print(f"  ✅ NSE EQ Downloader created successfully")
        print(f"  ✅ BSE EQ Downloader created successfully")
        
        # Check that fast mode is enabled
        fast_mode_enabled = hasattr(config.download_settings, 'fast_mode') and config.download_settings.fast_mode
        print(f"  ✅ Fast mode enabled: {'PASS' if fast_mode_enabled else 'FAIL'}")
        
        # Check timeout settings
        timeout_ok = config.download_settings.timeout_seconds >= 10
        print(f"  ✅ Adequate timeout: {'PASS' if timeout_ok else 'FAIL'}")
        
        return fast_mode_enabled and timeout_ok
        
    except Exception as e:
        print(f"  ❌ Error testing downloader error handling: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_config_yaml_updates():
    """Test that config.yaml has been updated correctly"""
    print("\n🔍 Testing Config YAML Updates...")
    
    try:
        config_path = Path("config.yaml")
        if not config_path.exists():
            print(f"  ❌ Config file not found: {config_path}")
            return False
        
        with open(config_path, 'r', encoding='utf-8') as f:
            config_data = yaml.safe_load(f)
        
        download_settings = config_data.get('download_settings', {})
        
        # Check key settings
        timeout_seconds = download_settings.get('timeout_seconds', 0)
        retry_attempts = download_settings.get('retry_attempts', 0)
        fast_mode = download_settings.get('fast_mode', False)
        
        timeout_ok = timeout_seconds >= 10
        retry_ok = retry_attempts >= 3
        fast_mode_ok = fast_mode is True
        
        print(f"  ✅ Timeout seconds ({timeout_seconds}): {'PASS' if timeout_ok else 'FAIL'}")
        print(f"  ✅ Retry attempts ({retry_attempts}): {'PASS' if retry_ok else 'FAIL'}")
        print(f"  ✅ Fast mode ({fast_mode}): {'PASS' if fast_mode_ok else 'FAIL'}")
        
        return timeout_ok and retry_ok and fast_mode_ok
        
    except Exception as e:
        print(f"  ❌ Error testing config YAML: {e}")
        return False

def main():
    """Run all download stability tests"""
    print("🚀 Download Stability Fixes Test Suite")
    print("=" * 50)
    
    tests = [
        ("Config YAML Updates", test_config_yaml_updates),
        ("Timeout Configuration Fixes", test_timeout_configuration_fixes),
        ("Error Classification", test_error_classification),
        ("Downloader Error Handling", test_downloader_error_handling),
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary:")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print(f"\n🎉 All download stability fixes working correctly!")
        print(f"\n💡 Key Improvements Made:")
        print(f"  - Increased timeout from 5s to 10s")
        print(f"  - Increased retry attempts from 2 to 3")
        print(f"  - Distinguished timeout errors from 404 errors")
        print(f"  - Improved error messages for better debugging")
        print(f"  - Enhanced fast mode error handling")
    else:
        print(f"\n⚠️  Some tests failed - please review the issues above")
    
    return passed == len(results)

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
